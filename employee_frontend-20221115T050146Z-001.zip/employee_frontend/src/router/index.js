import { createRouter, createWebHistory } from 'vue-router'

import Test from '../views/Test.vue'



const routes = [

  {
    path: '/',
    name: 'Test',
    component: Test,
    
  },
  {
    path: '/emp_add',
    name: 'employee Add',
    component: () => import( '../views/employeeAdd.vue')
  },
  {
    path: '/emp_update',
    name: 'employee Update',
    component: () => import( '../views/employeeUpdate.vue')
  },
  {
    path: '/department',
    name: 'department',
    component: () => import( '../views/department.vue')
  },
  {
    path: '/manager',
    name: 'manager',
    component: () => import( '../views/manager.vue')
  },
  {
    path: '/deptemp',
    name: 'deptemp',
    component: () => import( '../views/deptemp.vue')
  },
  {
    path: '/salary',
    name: 'salary',
    component: () => import( '../views/salary.vue')
  },
  {
    path: '/tittle',
    name: 'tittle',
    component: () => import( '../views/tittle.vue')
  },

]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
