<template>
    <div class="">
        <div class="grid grid-cols-12">
            <div class="col-span-12 pt-4">
                <router-link to="/" class="mr-2 text-white bg-btnDark hover:bg-btnDarkHover focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-md px-10 py-2 text-sm text-center disabled:opacity-75 disabled:cursor-not-allowed">Employee</router-link>
                <router-link to="/emp_add" class="mr-2 text-white bg-btnDark hover:bg-btnDarkHover focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-md px-10 py-2 text-sm text-center disabled:opacity-75 disabled:cursor-not-allowed">Employee Add</router-link>
                <router-link to="/emp_update" class="mr-2 text-white bg-btnDark hover:bg-btnDarkHover focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-md px-10 py-2 text-sm text-center disabled:opacity-75 disabled:cursor-not-allowed">Employee Update</router-link>
                <router-link to="/department" class="mr-2 text-white bg-btnDark hover:bg-btnDarkHover focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-md px-10 py-2 text-sm text-center disabled:opacity-75 disabled:cursor-not-allowed">Department</router-link>
                <router-link to="/manager" class="mr-2 text-white bg-btnDark hover:bg-btnDarkHover focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-md px-10 py-2 text-sm text-center disabled:opacity-75 disabled:cursor-not-allowed">Manager</router-link>
                <router-link to="/deptemp" class="mr-2 text-white bg-btnDark hover:bg-btnDarkHover focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-md px-10 py-2 text-sm text-center disabled:opacity-75 disabled:cursor-not-allowed">Department Employee</router-link>
                <router-link to="/salary" class="mr-2 text-white bg-btnDark hover:bg-btnDarkHover focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-md px-10 py-2 text-sm text-center disabled:opacity-75 disabled:cursor-not-allowed">Salary</router-link>
                <router-link to="/tittle" class="mr-2 text-white bg-btnDark hover:bg-btnDarkHover focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-md px-10 py-2 text-sm text-center disabled:opacity-75 disabled:cursor-not-allowed">Title</router-link>
            </div>
        </div>

        <div class="col-span-12">
            <div class="flex">
                <p class="ml-12 mr-2 mt-4 font-bold text-lg text-left">Manager Details</p>
            </div>

            <div class="mx-10 py-4 px-10 h-96 mt-6 rounded-lg bg-cardColor overflow-y-scroll">
                <table class="w-full text-sm text-left text-gray-500">
                    <thead class="text-xs text-black uppercase bg-blue-grey border-b-2 border-gray-300">
                        <tr class="">
                            <th scope="col" class="px-6 py-3">Employee No</th>
                            <th scope="col" class="px-6 py-3">Department No</th>
                            <th scope="col" class="px-6 py-3">From Date</th>
                            <th scope="col" class="px-6 py-3">To Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="e in manager" :key="e.id" class="border-b text-black">
                            <td class="px-6 py-4">
                                {{ e.emp_no }}
                            </td>
                            <td class="px-6 py-4">
                                {{ e.dept_no }}
                            </td>
                            <td class="px-6 py-4">
                                {{ e.from_date.slice(0, 10) }}
                            </td>
                            <td class="px-6 py-4">
                                {{ e.to_date.slice(0, 10) }}
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</template>

<script>
import api from "../../boot/axios";
export default {
    data() {
        return {
            searchId: "",
            manager: [],
        };
    },
    created() {
        this.getEmployeeData();
    },
    methods: {
        async getEmployeeData() {
            await api
                .get("/manager/")
                .then((res) => {
                    this.manager = res.data;
                })
                .catch((err) => console.log(err));
        },
    },
};
</script>

<style></style>
