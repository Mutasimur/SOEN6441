<template>
    <div class="">
        <div class="grid grid-cols-12">
            <div class="col-span-12 pt-4">
                <router-link to="/" class="mr-2 text-white bg-btnDark hover:bg-btnDarkHover focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-md px-10 py-2 text-sm text-center disabled:opacity-75 disabled:cursor-not-allowed">Employee</router-link>
                <router-link to="/emp_add" class="mr-2 text-white bg-btnDark hover:bg-btnDarkHover focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-md px-10 py-2 text-sm text-center disabled:opacity-75 disabled:cursor-not-allowed">Employee Add</router-link>
                <router-link to="/emp_update" class="mr-2 text-white bg-btnDark hover:bg-btnDarkHover focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-md px-10 py-2 text-sm text-center disabled:opacity-75 disabled:cursor-not-allowed">Employee Update</router-link>
                <router-link to="/department" class="mr-2 text-white bg-btnDark hover:bg-btnDarkHover focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-md px-10 py-2 text-sm text-center disabled:opacity-75 disabled:cursor-not-allowed">Department</router-link>
                <router-link to="/manager" class="mr-2 text-white bg-btnDark hover:bg-btnDarkHover focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-md px-10 py-2 text-sm text-center disabled:opacity-75 disabled:cursor-not-allowed">Manager</router-link>
                <router-link to="/deptemp" class="mr-2 text-white bg-btnDark hover:bg-btnDarkHover focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-md px-10 py-2 text-sm text-center disabled:opacity-75 disabled:cursor-not-allowed">Department Employee</router-link>
                <router-link to="/salary" class="mr-2 text-white bg-btnDark hover:bg-btnDarkHover focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-md px-10 py-2 text-sm text-center disabled:opacity-75 disabled:cursor-not-allowed">Salary</router-link>
                <router-link to="/tittle" class="mr-2 text-white bg-btnDark hover:bg-btnDarkHover focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-md px-10 py-2 text-sm text-center disabled:opacity-75 disabled:cursor-not-allowed">Title</router-link>
            </div>
        </div>

        <div class="grid grid-cols-12 mt-5 h-full mx-10 py-4 px-8 rounded-lg bg-cardColor">
            <div class="col-span-3 px-2">
                <div class="mb-4">
                    <label class="block text-gray-700 text-md font-bold mb-2 text-left pl-1" for="username"> Choose Employee: </label>
                    <select class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" v-model="selectedEId" required>
                        <option value="" disabled selected>Select a Employee Id</option>
                        <option v-for="e in employeeData" :key="e" :value="e.emp_no">{{ e.emp_no }}</option>
                    </select>
                </div>
            </div>
            <div class="col-span-8"></div>
            <div class="col-span-2 px-2">
                <div class="mb-4">
                    <label class="block text-gray-700 text-md font-bold mb-2 text-left pl-1"> Employee Id</label>
                    <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" type="text" placeholder="Please Input Employee Id" v-model="eID" />
                </div>
            </div>
            <div class="col-span-2 px-2">
                <div class="mb-4">
                    <label class="block text-gray-700 text-md font-bold mb-2 text-left pl-1"> Birth Date </label>
                    <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" type="date" placeholder="Please Input Birth Date" v-model="birthDate" />
                </div>
            </div>
            <div class="col-span-2 px-2">
                <div class="mb-4">
                    <label class="block text-gray-700 text-md font-bold mb-2 text-left pl-1"> First Name </label>
                    <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" type="text" placeholder="Please Input First Name" v-model="fName" />
                </div>
            </div>
            <div class="col-span-2 px-2">
                <div class="mb-4">
                    <label class="block text-gray-700 text-md font-bold mb-2 text-left pl-1"> Last Name </label>
                    <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" type="text" placeholder="Please Input Last Name" v-model="lName" />
                </div>
            </div>
            <div class="col-span-2 px-2">
                <div class="mb-4">
                    <label class="block text-gray-700 text-md font-bold mb-2 text-left pl-1"> Hire Date </label>
                    <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" type="date" placeholder="Please Input Hire Date" v-model="hireDate" />
                </div>
            </div>

            <div class="col-span-2 py-8">
                <button type="button" class="text-white bg-btnDark hover:bg-btnDarkHover focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-md px-10 py-2 text-sm text-center disabled:opacity-75 disabled:cursor-not-allowed" @click="postEmployee()">Post Employee</button>
            </div>
        </div>

        <div class="col-span-12">
            <div class="flex">
                <p class="ml-12 mr-2 mt-4 font-bold text-lg text-left">Employee Details</p>
                <button type="button" class="mt-4 text-white bg-btnDark hover:bg-btnDarkHover focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-md px-2 py-1 text-sm text-center disabled:opacity-75 disabled:cursor-not-allowed" @click="getEmployeeData()">Refresh</button>
            </div>

            <div class="mx-10 py-4 px-10 h-96 mt-6 rounded-lg bg-cardColor overflow-y-scroll">
                <table class="w-full text-sm text-left text-gray-500">
                    <thead class="text-xs text-black uppercase bg-blue-grey border-b-2 border-gray-300">
                        <tr class="">
                            <th scope="col" class="px-6 py-3">Employee Id</th>
                            <th scope="col" class="px-6 py-3">Birth Date</th>
                            <th scope="col" class="px-6 py-3">First Name</th>
                            <th scope="col" class="px-6 py-3">Last Name</th>
                            <th scope="col" class="px-6 py-3">Hire Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="e in employeeData" :key="e.id" class="border-b text-black">
                            <td class="px-6 py-4">
                                {{ e.emp_no }}
                            </td>
                            <td class="px-6 py-4">
                                {{ e.birth_date.slice(0, 10) }}
                            </td>
                            <td class="px-6 py-4">
                                {{ e.first_name }}
                            </td>
                            <td class="px-6 py-4">
                                {{ e.last_name }}
                            </td>
                            <td class="px-6 py-4">
                                {{ e.hire_date.slice(0, 10) }}
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</template>

<script>
import api from "../../boot/axios";
export default {
    data() {
        return {
            eID: "",
            birthDate: "",
            fName: "",
            lName: "",
            hireDate: "",
            employeeData: [],
            selectedEId: "",
        };
    },
    created() {
        this.getEmployeeData();
    },
    methods: {
        async getEmployeeData() {
            await api
                .get("/employee/")
                .then((res) => {
                    this.employeeData = res.data;
                })
                .catch((err) => console.log(err));
        },
        async postEmployee() {
            //id,bd,fn,ln,hd
            let employeeData = {
                id: this.eID,
                bd: this.birthDate,
                fn: this.fName,
                ln: this.lName,
                hd: this.hireDate,
            };
            await api.put(`/update/${this.selectedEId}/`, employeeData).catch((err) => console.log(err));
            this.eID = "";
            this.birthDate = "";
            this.fName = "";
            this.lName = "";
            this.hireDate = "";
            this.selectedEId = "";
            this.getEmployeeData();
        },
    },
};
</script>

<style></style>
